<!-- JAVASCRIPT -->
<!-- Vendor JS -->
<script src="<?php echo e(asset("public/js/vendor.bundle.js")); ?>"></script>
<!-- Theme JS -->
<script src="<?php echo e(asset("public/js/theme.bundle.js")); ?>"></script><?php /**PATH C:\xampp\htdocs\@sanmit\codegrand\IDA-new-web\resources\views/layouts/scripts.blade.php ENDPATH**/ ?>