<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Enquiry</title>
</head>
<body>
    <p><strong>Name:</strong> <?php echo e($contactData['name']); ?></p>
    <p><strong>Email:</strong> <?php echo e($contactData['email']); ?></p>
    <p><strong>Message:</strong> <?php echo e($contactData['message']); ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\@sanmit\codegrand\IDA-new-web\resources\views/emails/contactmail.blade.php ENDPATH**/ ?>