<!-- JAVASCRIPT -->
<!-- Vendor JS -->
<script src="{{ asset("public/js/vendor.bundle.js") }}"></script>
<!-- Theme JS -->
<script src="{{ asset("public/js/theme.bundle.js") }}"></script>